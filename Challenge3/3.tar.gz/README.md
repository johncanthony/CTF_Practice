Challenge 3
===========

I think that what needs to be done to solve this challenge is straight-forward
enough that I'm not going to leave a hint.
