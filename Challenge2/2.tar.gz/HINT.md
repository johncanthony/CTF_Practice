HINT
====

Hint 1
------

There's more than one way to skin a stegosaurus. If one method isn't doing it,
try a completely different one.

Super Sekrit Hint 1
--------------------

This looks shopped. I can tell from some of the pixels, and from having seen
quite a few shops in my time.
