Challenge 2
===========

I pulled this one out of my photo album so I could show you guys what a real
hacker looks like. I'm wearing PVC chemical gloves, lab goggles, a propellor
hat, and a disco ball necklace. Pretty stylin' if I do say so myself.

Remind me again what they call it when you stuff stuff in other stuff so that
people can't see the stuff? Stuffanography?
