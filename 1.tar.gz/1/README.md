Challenge 1
===========

Caesar stultum. Sum ingenio.
