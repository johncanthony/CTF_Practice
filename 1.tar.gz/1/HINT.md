HINT
====

When you're surrounded by noise, it can be hard to focus. Don't forget about
what you're looking for. Forma et Figura.
